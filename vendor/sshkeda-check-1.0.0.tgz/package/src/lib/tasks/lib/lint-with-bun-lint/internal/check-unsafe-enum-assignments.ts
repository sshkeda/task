import { Effect, FileSystem, Path, Schema, Stream } from "effect";
import { ChildProcess } from "effect/process";

import { encodeJson } from "../../../shared/encode-compact-json.ts";
import { ToolExited } from "../../../shared/project-config-and-tool-errors.ts";
import { tsgolintExecutable } from "./find-tsgolint-executable.ts";
import { EnumLintFailed, tsgolintRuleMessages } from "./read-tsgolint-rule-messages.ts";

const RULE_NAME = "no-unsafe-enum-assignment";
const PAYLOAD_VERSION = 2;

export const unsafeEnumExitsOn = (directory: string, files: readonly string[]) =>
  Effect.scoped(
    Effect.gen(function* () {
      const path = yield* Path.Path;
      const fileSystem = yield* FileSystem.FileSystem;
      const binary = yield* tsgolintExecutable;
      const input = yield* encodeJson({
        version: PAYLOAD_VERSION,
        configs: [
          {
            file_paths: files.map((file) => path.resolve(directory, file)),
            rules: [{ name: RULE_NAME }],
          },
        ],
      });
      const child = yield* ChildProcess.make(binary, ["headless"], {
        extendEnv: true,
        stdin: Stream.make(Buffer.from(input)),
        stderr: "pipe",
      });
      const [chunks, standardError, code] = yield* Effect.all(
        [
          Stream.runCollect(child.stdout),
          Stream.mkString(Stream.decodeText(child.stderr)),
          child.exitCode,
        ],
        { concurrency: "unbounded" },
      );
      const reports = yield* Effect.try({
        try: () => tsgolintRuleMessages(Buffer.concat(chunks)),
        catch: (cause) =>
          Schema.is(EnumLintFailed)(cause) ? cause : new EnumLintFailed({ reason: String(cause) }),
      });
      if (code !== 0) {
        return yield* new EnumLintFailed({ reason: standardError || `exit ${code}` });
      }
      const diagnostics = yield* Effect.forEach(
        reports.filter((report) => report.rule === RULE_NAME && report.file_path !== null),
        (report) =>
          Effect.gen(function* () {
            const filename = report.file_path ?? "";
            const source = yield* fileSystem.readFile(filename);
            const preceding = Buffer.from(source)
              .subarray(0, report.range?.pos ?? 0)
              .toString("utf8");
            const lines = preceding.split("\n");
            return {
              filename: path.relative(directory, filename),
              code: `typescript(${RULE_NAME})`,
              severity: "error",
              message: report.message.description,
              labels: [{ span: { line: lines.length, column: (lines.at(-1)?.length ?? 0) + 1 } }],
            };
          }),
      );
      if (diagnostics.length === 0) {
        return [];
      }
      return [
        new ToolExited({
          program: "oxlint",
          command: `${binary} headless`,
          code: 1,
          standardOutput: yield* encodeJson({ diagnostics }),
          standardError: "",
        }),
      ];
    }),
  );
