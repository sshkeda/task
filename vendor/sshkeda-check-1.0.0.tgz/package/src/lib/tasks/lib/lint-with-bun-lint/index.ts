import { Task } from "@sshkeda/task";
import { Effect } from "effect";

import { inEachPackage } from "../../shared/check-each-nested-package.ts";
import { lintConfigFile } from "../../shared/declare-lint-config-task.ts";
import { typeScriptConfig } from "../../shared/declare-typescript-config-task.ts";
import { checkLintRulesWithBunLintIn } from "./internal/check-lint-rules-with-bun-lint.ts";

export const bunLint = Task.make(
  "bun-lint",
  Effect.andThen(
    Task.all([typeScriptConfig, lintConfigFile]),
    inEachPackage("bun-lint", ".", checkLintRulesWithBunLintIn),
  ),
);
