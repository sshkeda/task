import { Array as Arrays, Effect, Path } from "effect";

import { FORMAT_CONFIG_FILE, LINT_CONFIG_FILE } from "../../../../../shared/config-file-names.ts";
import { installedBinary } from "../../../shared/find-installed-package-binaries.ts";
import { lintedFiles } from "../../../shared/list-linted-files.ts";
import { isFormatConfigTextRefusedIn } from "../../../shared/parse-config-files-that-import-from-check.ts";
import {
  quietToolFailure,
  quietViolations,
} from "../../../shared/print-failures-and-keep-detail-in-the-trace.ts";
import { ToolExited } from "../../../shared/project-config-and-tool-errors.ts";
import { TYPESCRIPT_PROJECT_FILE } from "../../../shared/query-the-typescript-project.ts";
import {
  argumentsInRunsOfBoundedSize,
  mergedExit,
  runTool,
} from "../../../shared/run-tools-and-decode-their-reports.ts";
import { unsafeEnumExitsOn } from "./check-unsafe-enum-assignments.ts";
import { tsgolintExecutable } from "./find-tsgolint-executable.ts";
import {
  BUN_LINT_TASK,
  bunLintReport,
  lintReportWithOriginalFileNames,
} from "./read-bun-lint-json-report.ts";

const BUN_LINT = "oxlint";

const oxlintBinary = Effect.gen(function* () {
  const path = yield* Path.Path;
  const packageDirectory = yield* path.fromFileUrl(new URL(".", import.meta.url));
  return yield* installedBinary(packageDirectory, "oxlint", "oxlint");
});

const BUN_LINT_ARGUMENTS = [
  "--config",
  LINT_CONFIG_FILE,
  "--disable-nested-config",
  "--no-ignore",
  "--tsconfig",
  TYPESCRIPT_PROJECT_FILE,
  "--format",
  "json",
  "--",
] as const;

const exitsOfBunLintOn = (directory: string) => (files: readonly string[]) =>
  Effect.gen(function* () {
    const binary = yield* oxlintBinary;
    const backend = yield* tsgolintExecutable;
    return yield* runTool(
      BUN_LINT,
      process.execPath,
      [binary, ...BUN_LINT_ARGUMENTS, ...files],
      directory,
      { OXLINT_TSGOLINT_PATH: backend },
    );
  }).pipe(
    Effect.as([]),
    Effect.catchTag("ToolExited", (exited) =>
      lintReportWithOriginalFileNames(BUN_LINT, exited.standardOutput, files).pipe(
        Effect.map((standardOutput) => [
          new ToolExited({
            program: exited.program,
            command: exited.command,
            code: exited.code,
            standardError: exited.standardError,
            standardOutput,
          }),
        ]),
      ),
    ),
  );

const bunLintExitsIn = (directory: string) =>
  Effect.gen(function* () {
    const path = yield* Path.Path;
    const files = yield* lintedFiles(path.join(directory, TYPESCRIPT_PROJECT_FILE));
    const isFormatConfigRefused = yield* isFormatConfigTextRefusedIn(directory);
    const filesTheFormatCheckDoesNotReport = files.filter(
      (file) => !isFormatConfigRefused || file !== FORMAT_CONFIG_FILE,
    );
    const exits = yield* Effect.forEach(
      [
        ...argumentsInRunsOfBoundedSize(
          filesTheFormatCheckDoesNotReport.filter((file) => !file.includes("\\")),
        ),
        ...filesTheFormatCheckDoesNotReport
          .filter((file) => file.includes("\\"))
          .map((file) => [file]),
      ],
      exitsOfBunLintOn(directory),
    );
    return [
      ...exits.flat(),
      ...(yield* unsafeEnumExitsOn(directory, filesTheFormatCheckDoesNotReport)),
    ];
  }).pipe(quietViolations(BUN_LINT_TASK));

export const checkLintRulesWithBunLintIn = (directory: string) =>
  Effect.gen(function* () {
    const exits = yield* bunLintExitsIn(directory);
    if (Arrays.isReadonlyArrayNonEmpty(exits)) {
      return yield* Effect.fail(mergedExit(exits)).pipe(
        quietToolFailure(BUN_LINT_TASK, (exited) =>
          bunLintReport(exited.program, ...exits.map(({ standardOutput }) => standardOutput)),
        ),
      );
    }
  });
